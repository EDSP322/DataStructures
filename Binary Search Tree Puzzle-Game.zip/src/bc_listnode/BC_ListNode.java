package bc_listnode;

import bc_gamenode.BC_GameNode;

public class BC_ListNode extends BC_GameNode{

    public BC_ListNode(int nodeDepth, int nodeIndex, int data) {
        
        super(nodeDepth, nodeIndex, data);
    }
}
